import json

class Task:
    def __init__(self, title, description="", status="pending"):
        self.title = title
        self.description = description
        self.status = status

    def mark_completed(self):
        self.status = "completed"

    def __str__(self):
        return f"{self.title} - {self.description} - {self.status}"


class ToDoList:
    def __init__(self):
        self.tasks = []

    def add_task(self, title, description=""):
        task = Task(title, description)
        self.tasks.append(task)

    def view_tasks(self):
        for i, task in enumerate(self.tasks):
            print(f"{i+1}. {task}")

    def delete_task(self, index):
        self.tasks.pop(index)

    def save_tasks(self, filename="tasks.json"):
        with open(filename, 'w') as f:
            json.dump([task.__dict__ for task in self.tasks], f)

    def load_tasks(self, filename="tasks.json"):
        with open(filename, 'r') as f:
            task_dicts = json.load(f)
            self.tasks = [Task(**task_dict) for task_dict in task_dicts]


to_do_list = ToDoList()
to_do_list.add_task("Buy groceries", "Milk, Bread, Eggs")
to_do_list.add_task("Do laundry")
to_do_list.view_tasks()
to_do_list.save_tasks()
